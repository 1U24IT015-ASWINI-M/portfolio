// Smooth navigation is handled by CSS.
// Add your LinkedIn and GitHub URLs to index.html when ready.
